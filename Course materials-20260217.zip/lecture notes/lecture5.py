# GENERAL INFO
# Register to exam -  registration closes 10 working days before!


# CHAPTER 4:
# - Nested loops (remaining from last lecture)

# CHAPTER 5
# - debugging (ie. error fixing). Up until and including 'Logging' section 5.3.3 
#   5.3.3.1 (Logging) and 5.3.4 (debuggers) are not included.
# - Algorithmic thinking (self study)
# - Data representation (self study)



# NESTED LOOPS


# Ex 1
# %%
for i in range(1,4):
    for j in range(1,4):
        print('outer: ', i, 'inner: ', j, i * j)
    
# %%


# Ex 2 (control flows)
# %%
for i in range(1,8):
    if i % 2 == 1:
        continue
    for j in range(1,8):
        if j % 2 == 0:
            continue
        print(i, j, i * j)
# %%

# Ex 3 initialize n*m matrix with zeros

M = []
n, m = 3, 4

for i in range(0,n):
    M.append([]) # new row
    for j in range(0,m):
        M[i].append(0)
print(M)  
# %%


# Ex 4 nested while

# %%
import random
#play = True
while True:
    correct = random.randint(1,100)
    print('Guess the correct number (1,100)')
    while True:
        guess = int(input("Guess a number: "))
        if guess > correct:
            print("Too large")
        elif guess < correct:
            print("Too small")
        else:
            print("Correct!!")
            break
    ans = input("do you want to play again? [yes]")
    if ans != 'yes':
        print("Bye")
        #play = False
        break
# %%



# DEBUGGING

# - syntactical mistakes 
#    Ex 1:  writing l = [2 4] instead of l = [2, 4])
#    Ex 2: def f(x)  # missing colon
#             return x
#
# - runtime errors (logical mistakes).


# GOTCHAS from lecture 2: 
# 1. List copying..
#    l2 = l # Copies only reference!
#    l2.append('hi')
#    print(l2, l)
#
# 2. Tuples containing mutable datatypes..
#   t2 = ([1, 2, 3], [3, 2, 1])
#   print(t2)
#   t2[0][1] = 99
#   print(t2)


# Sorting Issues (mistaken return value)
#%%
lst = [10, 3, 4]
#lst.sort() 
lst = sorted(lst)
print(lst)
#%%
for elem in lst:
    print(elem)

# Poor/no return value in your own functions
# %%
lst = [10,3,4,5,1,2]

def largest_three(lst):
    lst = sorted(lst)
    return lst[-3:]


res = largest_three([10,3,4,5,1,2])
# %%


# Understanding the Error Message
# %%
def f1(x):
    return f2(x)
def f2(x):
    return f3(x)
def f3(x):
    return 17 / x

f1([])
# %%


# DEBUGGING

# Ex: Collatz sequence not converging

def mult(n):
    return n*3 + 1

def div(n):
    return n//2

def algo(n):
    while n >= 1:
        if n % 2 == 1:
            mult(n)
        else:
            div(n)
algo(10)


# Assignment 1
# In the following exercise you are given a faulty ("buggy") function.
# Your task is to identify these bugs by reading the code line by line.
# When you read it, you should:
# 1. Find the bugs (try giving the function different lists)
# 2. Identify the cause of the bugs
# 3. Propose a solution


# 1: all_zero: a function that checks whether
#              all elements in a list are 0
#              and returns a boolean value.

def all_zero(p_list):
    """ Check if all elements are zero.
    :param p_list: list of integers
    :return: boolean
    """
    for x in p_list:
        if x != 0:
            return "False"
        else:
            return "True"

p_list = [0,0,0]
if all_zero(p_list):
    print('All elements are 0')
else:
    print('At least one element is not 0')






# Assignment 2: add_hyphens
#  add_hyphens('Hej') # Should return 'H-e-j'


def add_hyphens(text):
    """ Adds a hyphen between letters
    :param text: string
    :return: string
    """
    new_text = " "

    for idx in range(text):
        if idx == 0:
            # add first letter
            new_text = text[i] + "-"
        elif idx == len(text):
            # add last letter
            new_text = text[idx]

        new_text = text[idx] + "-"

    return new_text

# What are the bugs in this code?
# What tests can we write to find the bugs?
# How can we fix the bugs?


########################## IF TIME #############################
################################################################
################################################################



# ALGORITHMIC THINKING

# Read yourself.. but the gist:
#
#  - Programming is hard, because you need to 
#    describe everything in detail to the computer
#    (as compared to when your talking to a human - see pancake example)
#
#  - How to start writing a program:
#    * top-down: identify the key steps (eg functions) by breaking into subtasks.
#                then actually write the detailed code.
#                For this to work well, specify the exact input and output.
#                Ex: Identify most common k-mer in a genome. 
#                of each step.
#                1. read_fasta(...) -> ... 
#                2. compute_k_mers(...) -> ...
#                3. find_most_abundant() -> ...
#
#    * Bottom up: identify useful code that can then 
#                 be composed into a larger whole.
#
#    NOTE: Don’t choose between top-down and bottom-up; both are useful, 
#    the important thing is to work with the task. Don’t expect to
#    think -> see the solution -> write the code (esp. for beginner) 
#
#
#  - Always: 
#    1. Identify input and output
#    2. Finding an algorithm can be difficult -> create small examples (and test datasets)
#    3. How do you solve a task in your head? -> carefully trace the steps (ex: adding 44 + 42)
#    4. Sketch solutions with pen and paper
#    5. Think you got a solution?  It’s also good to consider corner cases (empty file, somthing is 0, etc).







# DATA REPRESENTATION


# Ex 1 polynoms

# Polynom list representation
p = [7, 3, 4] # 7 + 3x + 4x^2
p2 = [0,0,3,4] # 3x^2 + 4x^3

# Addition of polynoms (e.g., p + p2):
p_result = []
for i in range(p2):
    if i < len(p):
        p_result.append(p[i] + p2[i])
    else:
        p_result.append(0 + p2[i])

# What if sparse polynoms: p_sparse =  2x^3 + 7x^200
p_sparse = [0, 0, 0, 2, 0, .....]
p_sparse = { 3 : 2 , 200 : 7 }



# Ex 2 Matrixes

# Nested lists (e.g., rows are cells, columns are genes)
m = [[0,0,5,0],
     [4,0,0,1],
     [1,0,0,0],
     [0,0,0,0]]

print(m[0][2])

# Nested dictionaries
m = {0:{2:5},
     1:{1:4, 3: 1},
     2: {0:1}}

print(m[0][2])


# Ex 3: "Personal Identification Numbers" example in compendium - self study.


# %%

# Another exercise: Troubleshoot with Trace Prints

def derivative(polynomial):
    result = []
    degree = 1
    for term in polynomial:
        new_coefficient = term * degree
        result.append(new_coefficient)
        degree += 1
    return result

p = [1, 1, 1] # for p = 1 + x + x^2

# Debugging with print statements:
# insert print('degree term new_coefficient')
# and print(degree, term, new_coefficient) in for-loop

