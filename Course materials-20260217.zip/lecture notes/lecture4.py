# GENERAL INFO
# 1. Register to exam - registration closes 10 working days before!


# AGENDA
 
# CHAPTER 4
# - Dictionaries
# - File handling
# - More on loops: nested loops

# reminder on lists
l = ['23ghfyhfg3', 99, 'hej']
l[0]

# DICTIONARIES

# %%
credits = { 'DA7066' : 7.5, 'MM2001': 30}

# DA7066 - key
# 7.5    - value
# Keys and values don't have to be of the same type


 # Access
c = credits['DA7066']
print('Number of ECTS points for DA7066: ' + str(c))
# %% 

# Differences and similarities to lists:
# - similar syntax using '[]' for access
#    (i) list requres an offset (integer)
#    (ii) A dictionary requires the key
# 
# Example: l = [('DA7066', 7.5), ('MM2001', 30) ]
#          We would have to know the location of e.g. DA7066 to access




# variables as keys
x = 'DA7066'
y = 'MM2001'
credits = {x: 7.5, y: 30}
print('Number of ECTS points for DA7066: ' + str(credits[x]))


# Constructing a dictionary through iteration

# Ex 1

# Numbers and their squares
# %%
squared = {}
for i in range(1, 21):
    squared[i] = i**2
print(squared)
# %%






# Ex 2
# aquired data from expression experiment
# %%
l = ['HSPA8', 'DAZ1', 'HSPA8', 'HSPA8', 'TSPY4', 'DAZ1']

counts = {}
for gene in l:
    if gene not in counts:
        counts[gene] = 1
    else:
        counts[gene] += 1
        
print(counts)
print(counts['HSPA8'])
# wrong, cannot acces by index like: counts[2]
# %%

# Ex 3: Count k-mers in a genome 
#     A k-mer is a k long string of DNA (use e.g. k=3)
#     Tip 1: a k-mer at position i can be extracted as 
#            kmer = dna[i:i+k]

# %%
dna='ACGCATGCGACGACGACGACGTATTACGTT'

# answer should be a dictionary kmers = {kmer : count}


k = 3
kmers = {}
for i in range(0,len(dna) - k + 1):
    kmer = dna[i:i+k]
    if kmer in kmers:
        kmers[kmer] += 1 # kmers[kmer] = kmers[kmer] + 1
    else:
        kmers[kmer] = 1
print(kmers)
# %%
































# Solution
# kmers = {} 
# k = 3
# for i in range(0, len(dna) - k + 1):
#     kmer = dna[i:i+k]
#     if kmer not in kmers:
#         kmers[kmer] = 1
#     else:
#         kmers[kmer] += 1

# print(kmers)




# iteration over a dictionary:

# %%
# 1. Over keys only
for x in kmers.keys():
    print(x)
    # kmers[key] to get the value
# %%

# 2. Over values only
for values in kmers.values():
    print(values)

# 3. Over key-value pairs
for key, value in kmers.items():
    print(key, value)

# 4. Default (also over keys only - like in point 1)
for key in kmers:
    print(key)
    
#  You are not allowed to modify 
#  a dictionary during iteration.
for key in kmers.keys():
    del kmers[key]


# Allowed keys: strings, ints, floats, tuples ... (not mutable)
# lists can not (mutable)


l = [1,7,'hi'] 
t = (1,7,'hi') 

d = {}
d[l] = 3 # doesn't work
d[t] = 3 # works

d[t] = {'hej': {'a':2}}
# Other useful operations

# len - the number of items
print(len(kmers))
kmers['TTT'] = 23 # add element
print(len(kmers))
del kmers['AAA'] # delete element


# 'in' - look up keys  
print('TTT' in kmers)
print(23 in kmers)


############## EXAMPLE ON COMPUTING SPEED (IF TIME) ################
####################################################################
# 'in' is fast for large dictionaries, but slow for large lists

# %%
import random
# simulate a reference genome
reference = "".join([random.choice('ACGT') for i in range(1000000)])
k = 10

# kmers_list: list of all kmers from large sequence
kmers_list = [reference[i:i+k] for i in range(len(reference)-k+1)]

# kmers_dict: Dict of all kmers and their count from large sequence
kmers_dict = {}
for i in range(0, len(reference) - k + 1):
     kmer = reference[i:i+k]
     if kmer not in kmers_dict:
         kmers_dict[kmer] = 1
     else:
         kmers_dict[kmer] += 1


# simulate a genome from a patient
donor = "".join([random.choice('ACGT') for i in range(1000000)])

# Look up k-mers sequences from patient:
    
print('Start dict')
# Many searches in large data structure
for i in range(0, len(donor) - k + 1):
    kmer = donor[i:i+k]
    kmer in kmers_dict
print('Finish dict')

print('Start list')
# Many searches in large data structure
for i in range(0, len(donor) - k + 1):
    kmer = donor[i:i+k]
    kmer in kmers_list
print('finish list')
# %%
####################################################################
####################################################################


# Dictionaries: 
# * Look up is fast.
# * Easy to modify (add or delete element)
# * Easy to iterate over 
#
#
# lists and tuples: When you know order of items (can acces by index l[i])
# Dictionaries: Items order of items are not known, access by 'key'




# FILE HANDLING
# reading contents from file
# writing contents to file

# %%
# Create a variable h: a 'file handle' object prepared to read contents
infile = open('data/kmers.txt', 'r')  # 'r' for "read"
# %%

# Read the contents of the file (many ways)

# Ex 1
# %%
lines = infile.readlines() # whole file as list of strings
print(lines)
# %%

# Ex 2 (most common?)
# %%
for line in infile: # doesnt't load all contents at once
    print(line)

# move back to beginning of file with: infile.seek(0)
# %%

## Other ways

# Ex 3: whole file in string
full_file = infile.read() 
print(full_file)


# Ex 4: With h.readline()
l =  infile.readline() # one line at a time





## Write to file

outfile = open('data/out_data.txt', 'w')

# Alternative 1
outfile.write('This is my first line')
outfile.write('\n')
outfile.write('This is my second line')

# Don't forget to close the file before viewing its contents
outfile.close()


# Important to close files:

# * Number of open files limited in a operating system
# * Another program may want access to an open file 
# * You can lose data if you havent closed the file.
#
# When a program terminates, open files are closed automatically.
# but still considered good programming habit to close them explicitly. 



# Putting it all together
# Filter only abundant k-mers:

# %%
infile = open('data/kmers.txt', 'r')
outfile = open('data/out_kmers.txt', 'w')
for n in infile:    # loop through the file, row by row
    kmer, count = n.split(',')
    if int(count) > 4:
        outfile.write(kmer + ',' + count)
outfile.close()
infile.close()
# %%

# "with": idiomatic Python.
# Improves readability, better structure

with open('data/out.txt', 'w') as outfile:
     outfile.write("hej hopp")
    
# equivalent to

out = open('data/out.txt', 'w')
out.write("hej hopp")
out.close()



# Filter only abundant k-mers using "with" statement
with open('data/kmers.txt', 'r') as infile, open('data/out_kmers.txt', 'w') as outfile:
    for line in infile:
        kmer, count = line.split(',')
        if int(count) > 4:
            outfile.write(kmer + ',' + count + '\n')    


# * Reading and writing files is slow
#   - Avoid reading twice.
# * Some files are large:
#    - Avoid reading the whole file if possible (out of memory - 'hangs')
# * Avoid hard coding file paths. Another user wont have the same file path as you. 
# * Temporary files should have unique and temporary names ('tmp.txt' 'temp.csv') to be removed.
#   - Use the module `tempfile`
#     ([https://docs.python.org/3/library/tempfile.html](https://docs.python.org/3/library/tempfile.html)
#     easy and convenient!



# NESTED LOOPS


# Ex 1

for i in range(3):
    for j in range(3):
        print(i * j)


# Ex 2

print('i  j  i*j')
print('---------')
for i in range(1,4):
    for j in range(1,4):
        print(i, j, i * j, sep='   ')
    print('---------')


# Ex 3 (control flows)

for i in range(1,8):
    if i % 2 == 1:
        continue
    for j in range(1,8):
        if j % 2 == 1:
            continue
        print(i * j)


# Ex 4

# Guessing game
# One letter is randomly sampled from a set of words 
# and shown to user.
# User guesses a word. If guess is correct, the word is removed.
# Otherwise all words remain. 
# A new letter is sampled from remaining words until
# no more words.

import random
word_list = ['house', 'hamster', 'mast', 'summer', 'sun']
nr_guesses = 0
while word_list:
    # print remaining words
    print('Current remaining words', word_list)

    # selects a random word and one letter from the word
    word = random.choice(word_list)
    letter = random.choice(word)
    print('Current word contains letter:', letter)

    # make user guess
    guess = ''
    while guess != word:
        guess = input('Guess the word: ')
        nr_guesses += 1
        if guess == word:
            print('Correct!')
            word_list.remove(word)
            break
        else:
            print('Try again!')

print('You completed the game in ', nr_guesses, 'guesses.' )

