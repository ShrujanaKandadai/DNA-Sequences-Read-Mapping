
# GENERAL INFO
# Register to exam -  registration closes 10 working days before!
# Lecture notes available under: Course materials/lecture notes


# CHAPTER 3

# - Lists
# - Tuples
# - range

# - for loops
# - Control flow: pass, continue, break och return
# - while loops



# LISTS
# %%
mylist = ['hi', 2, 'you']
l = []
# %%

# indexing/access - starts at index 0!
print(mylist[0])
print(mylist[1])
print(mylist[2])

# %%

# Trick if long list (or unknown length)
print(mylist[-1])
print(mylist[-2])
print(mylist[-3])

# %%
# index error
print(mylist[3])

# %%
# Add an element to the end of a list with "append".

mylist.append(6)
print(mylist)

mylist.append('more')
print(mylist)

mylist.append(True)
print(mylist)
# %%
mylist.append([1,2,3])
print(mylist)
# %%

# Assign a new value
mylist[1] = 5
print(mylist)

mylist[-2] *= 3
print(mylist)

# %%
# slicing

print(mylist[0:1])
print(mylist[0:2])
print(mylist[1:3])
print(mylist[1:4])
# %%

# Operations on lists
s = mylist + mylist
print(s)
t = 3 * mylist
print(t)
# %%
del mylist[2]
# %%

# Useful function len()

n = len(mylist)
print(n)
# %%

# min and max

print(min([2,5,1,-2,100]))
print(max([2,5,1,-2,100]))
# %%

# Find the index 

print(mylist.index('hi'))
print(mylist.index(3))
# %%

# count occurences

print(mylist.count(5))
print(mylist.count(42))
# %%

# The in operator

print(5 in mylist)
print('hej' in mylist)

# used a lot for things like:
if x in mylist:
    ...
else:
    ...
# %%
# Also for strings
print('gg' in 'eggs')


# %%

# TUPLES

# VERY simplified: 'tuples are lists that cannot be modified'

# %%
l = [4,2,7]
t = (4,2,7)

# Many of the same operations:
print(l[0], l[1:3]) # indexing, slicing
print(t[0], t[1:3]) # indexing, slicing
print(len(l), min(l), max(l))
print(len(t), min(t), max(t))
# %% 

# lists are mutable but tuples not
l.append(3)
t.append(3)

# %% 
l[1] = 100
t[1] = 100

# %%
# Two GOTCHAS:

## 1. List copying..
l2 = list(l) # Copies only reference!
l2.append('hi')
print(l2, l)
# Solution? -> reconstruct using list(l)

# %%
# 2. Tuples containing mutable datatypes..

# They can hold mutable types...
t2 = ([1, 2, 3], [3, 2, 1]) # don't construct structures like this
print(t2)
t2[0][1] = 99
print(t2)

# %%

# RANGE 
# practical for creating lists 
# with numbers (often for iteration)

# %%
my_list = list(range(1, 4))
print(my_list) 
# %%

print(list(range(3))) # Same as range(0, 3) 
print(list(range(4, 2))) # empty
print(list(range(13, 2, -1))) # decrement
print(list(range(0, 10, 3)))

# %%
# reminder: dont overwrite the inbuilt functions
# list = [1,2,3]
# str = 'hej'
# int = 2

list(range(1,3))


# %%
# FOR LOOPS - 'iteration over enumerations'

l = [1, 2, 3]

for num in l: 
    print('num:', num)
    y = num**3
    print('y:', y)
    print()
# %%

# or 

numbers = list(range(1, 4))
for x in numbers:
    print(x)
# %%

# If numbers is only used in one place, we dont have
# to declare it as a variable but can instead do

for x in range(1, 4):
    print(x)


# Some more examples
# %%
s = 'A number: '
for x in range(2, 7, 2):
    s += str(x)
    print(s) 

print(s) 

# %%
# Also looping over tuples 
# for x in (2, 4, 6):
#    ...

# Also looping over strings 
for char in 'DA7066': 
    print(2*char)

# %%





#%%
dna='ACGCATGCGACGACGACGACGTATTACGTT'

# List with k-mers
kmers = [] 
k = 3
for i in range(0, len(dna)-k+1):
    kmer = dna[i : i+k]
    kmers.append(kmer)

print(kmers)
#%%


# CONTROL FLOW

## continue, break, return, pass

## continue
# %% 
for i in range(4): 
    if i == 1: 
        continue 
        print('iteration:', i) 
    else: 
        print('iteration:', i) 
# %%

## break

for i in range(4): 
    if i == 1: 
        break 
        print('iteration:', i) 
    else: 
        print('iteration:', i) 
# %%

## return (för funktioner)

def first_even_number(l):
    for number in l:
        if number % 2 == 0:
            return number

print(first_even_number([1, 45, 24, 9, 4]))

## pass - can be used as a placeholder for unfinished code

def f():
    pass

# first, what happens with our previous example: 
for i in range(4): 
    if i == 1: 
        pass 
        print('iteration:', i) 
    else: 
        print('iteration:', i) 

# ex 1 - in a function

def first_even_number(l):
    pass

# ex 2 - i loop

for i in range(4): 
    if i == 1: 
        pass 
    else: 
        print('iteration:', i) 



# Warning - mutability 

# Lists can be modified, even under iteration

animals = ['cat', 'dog', 'tortoise', 'rabbit']

for x in animals:
    if len(x) > 6:
        animals.append(x)

print(animals)




# WHILE LOOPS


# for loops - For known number of iterations
# while loppar - For unknown number of iterations

# %%
# Ex 1
loop = True
while loop:
    print("Write 'exit' to quit")
    answer = input('Write something: ')
    if answer == 'exit':
        print('Goodbye!')
        loop = False
    else:
        print('Let us keep going!', answer)

# version 2

while True:
    print("Write 'exit' to quit")
    answer = input('Write something: ')
    if answer == 'exit':
        print('Goodbye!')
        break
    else:
        print('Let us keep going!', answer)
# %%


# Ex 2 

# random is used for sake of example of 'unknown' data
# but you can also think of a file with unknown numbers generated 
# from an experiment (e.g., expression data etc)

# %%
import random 
times = 0
while True:
    n = random.randint(1,1000)
    times += 1
    if n % 10 == 0:
        break

print('Times simulated before evenly divisible with 10:', times)
# %%














################## IF TIME ########################


# Ex 3

# Guessing game
# One letter is randomly sampled from a set of words 
# and shown to user.
# User guess a word. If guess is correct, the word is removed.
# Otherwise all words remain. 
# A new letter is sampled from remaining words until
# no more words.

import random
word_list = ['House', 'hamster', 'mast', 'summer', 'sommar', 'sun']
nr_guesses = 0
while word_list:
    # print remaining words
    print('Current remaining words', word_list)

    # select a random word and one letter from the word
    word = random.choice(word_list)
    letter = random.choice(word)
    print('Current word contains letter:', letter)

    # make user guess
    guess = ''
    while guess != word:
        guess = input('Guess the word: ')
        nr_guesses += 1
        if guess == word:
            print('Correct!')
            word_list.remove(word)
            break
        else:
            print('Try again!')

print('You completed the game in ', nr_guesses, 'guesses.' )



# EXAMPLE: Suppose we want to produce 10 randomly sampled integers
# between 1 and 100 that must be divisible by
# 3, 5, or 7.
# Purpose: Practice using of lists, while, for
# Think of:
# * while - iteration over unknown number
# * for - iteration over known number


# (solution below)











import random
l = []
divs = [3,5,7]
while len(l) < 10:
    n = random.randint(1,100)
    for d in divs:
        if n % d == 0:
            l.append(n)

print(l)



# %%
