# GENERAL INFO

# Use todays lab session to install and get aquainted with Python and your editor of choice (e.g. VScode).


# CHAPTER 1


# * Short about VScode IDEs (installing extensions, running code, the terminal etc.)
# Disable Github copilot (or disable "inlineSuggest").
# * Short about running cells and installing jupyter extension (NOT NEEDED AND NOT ON CHAPTER YET, BUT NICE TO HAVE)
#     In terminal:
#      1. conda create -n jupyter-env python=3.11 jupyter
#      2. conda activate jupyter-env
#      3. when pressing "run cell" in VScode, select "jupyter-env" as kernel

# - Variables 
# - strings
# - print
# - arithmetic operations
# - input
# Reserved words and names in Python



# Variables
# %%
d = 67
t = 1.5
v = d / t
print(v)
# %%





# %%


# some letters common variable names: 
# n,m fixed quantities (e.g. [1,n])
# i, j for iteration (index in mathematics)


# naming a variable
# %%
distance = 67  
time = 1.5  
velocity = distance / time 
print(velocity)

# %%
x = 0
y = x * (x + 5)
x = y
print("x = " + str(x))
print("y = " + str(y))

# %%
# Not allowed:
5 = y
print = 10

# many assignment on one line
x, y = 10, 5


# Comments
distance = 67 # Measured by GPS  
time = 1.5 # Estimated by me 
velocity = distance / time 
print(velocity)

# Arithmetic operations

print(2 + 3) # space not matter: print(2+3)
print(2 - 3)
print(2 * 3)
print(2 ** 3)
print(10 % 3)
print(22 / 7)
print(22 // 7)

print(2^3) # What happens here ??


# String handling and print

print("hej")
print('hej')

print("h'e'j")
print('h"e"j')

# String operations:

print('Mid' + 'summer')

print('hi' + ' ' + 'there')

print('hi' + 2) # not defined
print('hi' * 7) # works
print('hi' * 'hi') # not defined
print('hi' - 'hej') # not defined

# Input

name = input("Please enter your name: \n") # returns a string!

print("Hi " + name)


# Reserved words
True
False 
None 
with 
as 
import
from
and 
except   
while 
assert  
break 
for 
not  
or 
continue 
global 
pass 
def 
if 
raise 
del 
return 
elif 
in 
else 
is 
try

# Alsowe will not encounter:
lambda
yield
class
finally
    
# E.g. try:
while = 13


# Identifiers

# Identifers are -names-. for resources. A "resource" can be 
# a variable, a function (Chapter 2) or other python resources in 
# Python (that are not part of this course, e.g. objects and classes). 

# Rules for identifers:
# May contain letters, digits and underscore (_).
# Cannot begin with a digit.
# Python is case sensitive; Year and year are not the same identifer.

my_var = 4
My_var = 5
print(my_var, My_var)

# Make sure to choose good identifers to make the code easier to read! 
# Naming a variable for someones age as age is much more informative than x.







