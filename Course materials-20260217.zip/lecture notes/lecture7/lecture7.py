# GENERAL INFO
# Register to exam -  registration closes 10 days before!
# Exam has identical format and rules to previous exams:

# 1. If a multiple choice question has several correct answers, 
#   you must give all correct answers to receive credit.
# 2. Write clearly. Answers that are difficult to read may receive 0 points.
# 3. You must pass part A (4 correct out of 8 questions) to have your 
#   part B graded.
# 4. Write only on one side of each paper!
# 5. No import are allowed in your answers in part B (neither Python’s 
#   standard modules nor external libraries) unless it is explicitly 
#   mentioned in the assignment. Built-in functions like len, range, print,
#   and sum are allowed.
# 6. Aids: An A4 with as much information as you want. You can write on 
#   both sides.
# 7. Grade thresholds: E: 10, D: 12, C: 14, B: 16, A: 18, of maximum 20.




# CHAPTER 7
# 
# - Modules (and the main function)
# - Libraries
#     * Matplotlib (for JSON and numpy see compendium - you don't need to learn it)
# - Guidelines for how to write good code 
#   (read Basic principles of programming under resources)




# MODULES
# A module is a .py file. It binds together functions, variables (and classes, chapter 3). 
# Modules are useful for:
# * Code Reuse -- import code written by other programmers (or yourself).
# * Structure -- working with a large amount of code in a single file is 
#   challenging, so distribute it across multiple files.
# * Collaboration -- it's much easier to write code together as a team 
#   if it's maintained in multiple files, avoiding everyone modifying the
#   same file.

#  Design: Understanding a module's interface (how to import and use the functions) should be sufficient.

# * Each Python file is a module.
# * Everything to be used (from another file) must be imported.

# Syntax: 
import m # imports a module (file) m.py



# Example 1: 
# Create a module 'm.py' with, for instance, a function add(x, y).
# Import the module and use the function add.


# Example 2: The existing python module 'random'

import random
    



# Executing code as a module or as the 'main script'
## The magic if __name__ == '__main__': statement

# Add below code to module m.py (example 1) and 
# 1. import m.py (use as module)
# 2. Run m.py as a script (i.e., as the main file)


def main():
    print("python main function")

if __name__ == '__main__':
    main()

print("__name__ value: ", __name__)



# Example 3 Creating a circle module with some functions

# Use as module:
import circle

r = 1
print(circle.area(r))

print(circle.circumference(r))

# Run the circle.py as main file to execute the 'tests' (not really tests - more about tests in chapter 7)



# HAVING A MAIN FUNCTION IS CONVENTION

## The main() function

def main():
    data = read_fasta(...)
    expr_levels = compute_expression(data)
    .. = compute_...()
    write_output(...)








# Various ways to import.

# 1
import math # One of Python's already implemented modules
math.ceil(3.5)  # Round up
ceil(4.4)  # Doesnet work!

# 2
from math import ceil

ceil(4.4)  # works!

# 3
import math as M

M.ceil(4.7)

# 4 (avoid name collisions)

# for example if you have your own function 'gcd'

from math import gcd as libgcd

def gcd(a,b): # egen funktion
  r = a % b
  if r == 0:
      return b
  else:
      return gcd(b, r)

for a in range(2,10):
  for b in range(2,a):
      print(gcd(a,b) == libgcd(a,b))



## The four ways in an example:
# 1
import math
def binom1(n, k):
    return math.factorial(n) / (math.factorial(k) * math.factorial(n-k))

# 2
import math as m
def binom2(n, k):
    return m.factorial(n) / (m.factorial(k) * m.factorial(n-k))
```

# 3
from math import factorial
def binom3(n, k):
    return factorial(n) /(factorial(k)*factorial(n-k))
```

# 4
from math import factorial as fac
def binom4(n, k):
    return fac(n) /(fac(k)*fac(n-k))



# Useful modules

## Computing 
# * `math` -- Mathematics: trigonometry, logarithms, etc
# * `random` -- Probabilities, random number generators
# * `matplotlib` -- Visualization of data
# * `itertools` -- iterating over complex combinatorics (permutations, combinations with/without replacement)

## File handeling, I/O 

# * `sys` -- about the python interpreter (memory usage, garbage collection)
# * `os` -- advanced handling of files and independence on Operating system
# * `argparse` -- Interact with terminal, for writing programs

# Not part of standard distribution:
# * `numpy` and `scipy` -- Large scale mathematical computing, vectors, matrices, large data statistics
# * `pandas` -- Data analysis
# * `seaborn` -- Vizualization and data analysis





# MATPLOTLIB

from matplotlib import pyplot

# Functions
xs = [1,2,3,4]
ys = [1,4,9,16]
pyplot.plot(xs, ys)

pyplot.title("A title")
pyplot.xlabel("x")
pyplot.ylabel("x^2")

# pyplot.savefig("/X/Y/graph.pdf") # save to file
pyplot.show() # to show plot

pyplot.clf() # this clears the figure for any upcoming plots

# Histograms
from matplotlib import pyplot
# most expressed gene in sample, 10 experiments
expressed = ['DAZ', 'GCLC', 'MAPK8', 'BAX', 'GCLC', 'GCLC', 'DAZ']
pyplot.hist(expressed)
pyplot.show()

# Scatter plots
from matplotlib import pyplot
xs = [1,2,3,4]
ys = [1,4,9,16]
pyplot.scatter(xs, ys)

from matplotlib import pyplot
t_scores = [100,57,24,43,90,62]
t_attendance = [100,90,54,98,76,21]
f_scores = [84,76,64,48,51,70] 
f_attendance =  [79,67,41,53,80,52]
pyplot.scatter(t_scores, t_attendance, color='r', label='traditional')
pyplot.scatter(f_scores, f_attendance, color='b', label='flipped')
pyplot.xlabel("Score")
pyplot.ylabel("Attendance (%)")
pyplot.legend()
pyplot.show()


# GUIDELINES FOR GOOD CODE

# 1.
# * Avoid long lines. 
#   Bad:

if <complex comparison> and <other complex comparison>:
   # do something

with open('data/kmers.txt', 'r') as infile, open('data/out_kmers.txt', 'w') as outfile:

#  Good:

cond1 = <complex comparison>
cond2 = <other complex comparison>
if cond1 and cond2:
    ...

inh = open('data/kmers.txt', 'r')
outh = open('data/out_kmers.txt', 'w')
with inh as infile, outh as outfile:
    ...


#2. Functions:
#  - Strive to write short functions 
#  - Divide up code into functions that do one thing and do it well 
#    (easier to read, test, and understand)
#  - Separate calculation and interaction
#  - Functions should return something.
#  - Functions should depend (only) on their parameters (aviod global variables)
#  - Every function should have a documentation string.
#  - Use informative function names (undantag: main )
#      Bad: `start`, `compute`, `f`, `foo`
#      Good: `remove_outliers`, `newton_raphson`, `compute_integral`



# Bad ex 1: depends on global variables
b = 3
def calc(a): # not good
    c = (a**2 + b**2)**0.5
    return c


# Bad ex 2: no return
def calc(a, b):
    c = (a**2 + b**2)**0.5
    print(c) # not good



# Good: better naming
def hypotenuse(a,b): # better
    c = (a**2 + b**2)**0.5
    return c


# Best: documentation
def hypotenuse(a,b):
    """Computes the hypotenuse c of a triangle
        with two perpendicular sides a and b.
    
    Parameters:
    a (int): Non-negative side length of triangle
    b (int): Non-negative side length of triangle
    
    Returns:
    int: hypotenuse of 
    """
    c = (a**2 + b**2)**0.5
    return c


# Also: return a suitable datatype
# Multiple returns practical - better than packed strings 

def f(x):
	return '2'

if f(1) == 2:
	print("This is not printed!")
else:
	print("This is printed!")




# 3. Divide code into small units, i.e., suitable functions (and modules)
#    This is called "modular code": Each logical part in the code can be 
#    studied in its own context and can be combined with other parts into complex programs 
#    - more managable and understandable.


# 4. Variables:
#    * instead of hardcoded litterals. Ex:
#      width , height  = 600 , 600
#      instead of repeating these values everywhere. 
#    * Avoid global variables.
#    * variable names: should be clear from name what it stores 

# Not so good
x = 17  # critical value, abort if exceeding

# Better
critical_value = 17  # abort if exceeding

# Not so good
nc = 1.7       # normalization constant

# Better
normalization_constant = 1.7


# Signs of not-so-good code

# * It is difficult to design good tests? Then its not modular enough. 
# Solution: refactor into better functions

# * Deep indentation:  Example

######## VERSION 1 ########

# Print the prime numbers from a collatz sequence
# for 100 consecutive starting numbers
for i in range(1,100):
    	n = i
    	primes = []
    	while n != 1:
      		is_p = True
      		for x in range(2, n):
        			if not (n % x):
        				is_p = False
      		if is_p:
      			primes.append(n)
      		if n % 2 == 0:
      			n = n//2
      		else:
      			n = 3*n + 1
print("Start number :", i, "Primes in Collatz sequence: ", primes)
#############################


######## VERSION 2 ########

def collatz_update(n):
	if n % 2 == 0:
		return n//2
	else:
		return 3*n + 1

def is_prime(n):
	if n < 2:
		return False
	if n == 2:
		return True

	for y in range(2,n):
		if n % y == 0:
			return False
	return True

def collatz_primes(n):
	"""Computes prime numbers from
    	the collatz sequence for an integer n.
    	Parameters:
    	n (int): input number
    	Returns:
    	list: list of prime numbers in collatz sequence for n
	"""
	primes = []
	while n != 1:
		if is_prime(n):
			primes.append(n)
		n = collatz_update(n)
	return primes

for i in range(1,100):
	primes = collatz_primes(i)
	print("Start number :", i, "Primes in Collatz sequence: ", primes)
#############################

# Which version is easier to understand?
# Which version is easier to test for bugs?





####################################################
####################################################

# EXERCISES

# 1.  Importera biblioteket `random` (se
#     <https://docs.python.org/3/library/random.html>) för att generera
#     10 slumpnässiga _heltal_ mellan 1 och 100 och 10 slumpnässiga
#     _flyttal_ mellan 1 och 100.

#     _Tips:_ Läs dokumentationen. Vilka funktioner är lämpligast att
#     använda?

# 2 Förbättra strukturen på nedanstående program

# # checks if a number is (1) perfect (2) prime
# x = int(input("Provide a number to analyze: \n"))
# sum = 0
# for i in range(1, x):
#     if (x % i == 0):
#         sum = sum + i

# if x >= 2:
#     prime = True
#     for y in range(2,x):
#         if not (x % y):
#             prime = False
# else:
#     prime = False

# if sum == x:
#     print("The number is perfect")
# else:
#     print("The number is not perfect")
# if prime:
#     print("The number is prime")
# else:
#     print("The number is not prime")


# 3.  Lägg till i ditt omstrukturerade program från uppgift 2 valet att
#     låta användaren bestämma om hen ska ange ett tal eller om
#     programmet ska slumpa fram ett tal. Var i programmet bör vi
#     placera denna nya kod?



