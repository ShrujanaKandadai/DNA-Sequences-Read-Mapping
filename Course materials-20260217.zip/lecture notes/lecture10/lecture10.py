# GENERAL INFO
#
# Tomorrow: course summary
# Friday: Will go through exam 2025-03-04
# 


# CHAPTER 10
# - Error handling (exceptions and raise)

import pandas
import scipy
import numpy

# NumPy

# For efficeint computation (e.g. looping)

# Illustrate difference between a python list (list of pointers) vs an array
# Numpy implements an "ndarray" - and N-dimensional array.
# Backbone of many other libraries in Python.

l = [5, "ACGTCGA...", True, [1,2,3,4] ]

for x in l:
    print(x)

import numpy as np
a = np.array([1, 2, 3, 4, 5])

for x in a:
    print(x)

# also:
b = np.array([1, 2, 3, 4, 5], dtype=float)
print(a)
print(b)

# and also: BUT...
c = np.array([1, 2, 3, 4, 'hej']) # works without errors but..
print(c)
# Numpy: "What single data type can represent all of these values?"


# Examples:
d = np.array([[1, 2, 3],
              [4, 5, 6]]) # 2D array

zeros = np.zeros((3, 4))     # 3x4 array of zeros
ones  = np.ones((2, 2))      # 2x2 array of ones
rng   = np.arange(0, 10, 2)  # [0, 2, 4, 6, 8]
lin   = np.linspace(0, 1, 5) # 5 points between 0 and 1



# Pandas

# Pandas introduces two primary structures: 
#  1. The Series, representing a labeled one-dimensional
#     data array (think a list, but implemented in NDarray)
#  2. The DataFrame, a flexible two-dimensional table resembling 
#     an Excel sheet (think list of lists,  but implemented in NDarray)

# Pandas data loading
import os
import pandas as pd
data_file = os.path.join('data', 'data.txt')
df = pd.read_csv(data_file)

###############################################
# Inspecting the data
df.head()        # first 5 rows
df.tail()        # last 5 rows
df.info()        # column names, dtypes, missing values
df.describe()    # summary statistics (numeric columns)
df.shape         # (rows, columns)
df.columns       # column names

# Selecting data

# By column
df['x']                  # single column (Series)
df[['x', 'y']]           # multiple columns

# By row
df.loc[0]                # row by label
df.iloc[0]               # row by position
df.loc[10:20]            # slice by labels
df.iloc[10:20]           # slice by index

# Conditional selection
df[df['x'] > 10]
df[(df['x'] > 10) & (df['y'] < 5)]

# Basic statistics
df.mean()
df.median()
df.std()
df.min()
df.max() 

df['x'].mean()
df[['x', 'y']].mean()

# Creating and modifying columns
df['z'] = df['x'] + df['y']
df['log_x'] = np.log(df['x'])

# Handling missing data..
# Sorting and filtering..
# Aggregation and grouping..
# Merging and joining..
# Plotting (quick looks)..

###############################################


xdata = df['x'] # extracting the x values
ydata = df['val'] # extracting the measurement values

print(xdata)
mean_x = xdata.mean()     # compute the mean
print(mean_x)


# Matplotlib
from matplotlib import pyplot
pyplot.scatter(xdata, ydata)
pyplot.title("Sample4")
pyplot.xlabel("x")
pyplot.ylabel("Val")
pyplot.savefig("plot-sample4.pdf")


# SciPy 
# 
# implements advanced algorithms used in mathematics, engineering, and the natural sciences. 
#  - optimization
#  - statistics (fit regression models and run statistical hypothesis tests)
#  - signal processing 
# SciPy offers reliable, well-tested implementations.



# Scipy and statistical analysis
from scipy import stats
slope, intercept, r_value, p_value, std_err = stats.linregress(xdata, ydata)
print("Slope = ", slope)
print("Intercept = ", intercept)
print("R-squared = ", r_value**2)
print("P value = ", p_value)
print("Standard error = ", std_err)





# Plot regression line
## BUG IN COMPENDIUM: variable "line" is not defined.
line = intercept + slope * xdata # this should be added in the compendium
pyplot.plot(xdata, line, label="Linear fit") 
# Labels and title
pyplot.title("Sample4")
pyplot.xlabel("x")
pyplot.ylabel("Val")
pyplot.legend()
pyplot.savefig("plot-sample4-linear_fit.pdf")




# Chapter 10.2 Why you still need classical coding skills
#
# 1. Non-tabular and large data (e.g. Fasta and Fastq files)

# i. FASTA is not row-based, it is hierarchical, with header information 
#    followed by the sequence (possibly many lines).
# ii. There is no fixed schema; sequences can be of different lengths.
#    
# 2. Several file formats in bioinformatics are tabluar based, 
#    e.g., SAM, GTF, VCF, they are often very large and cannot be loaded
#    in full.

# Most computational problems are not solved by tabular 
# data processing -- but with classical algorithms.
#
# Example 1: Computing GC Content in Sliding Windows
#
# Example 2: Finding Open Reading Frames (ORFs)

# For example, bioinformatics requires understanding and implementing
# algorithms working on e.g. sequnence, signal or image data. This is 
# why classical programming skills such as loops, conditionals, 
# functions, and basic data structures (e.g., lists and dictionaries) 
# are essential.