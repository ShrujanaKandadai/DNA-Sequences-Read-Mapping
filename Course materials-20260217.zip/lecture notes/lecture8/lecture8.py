# GENERAL INFO
# Register to exam -  registration closes 10 days before!



# CHAPTER 8
# 
# - Running Python code from the terminal
# - Parsing arguments from commandline
# - The argparse module
# - Testing (with assert)

# The terminal (command prompt)
## Why?
# typical bioinformatic pipeline:
#
# cut_adapt reads.fa trimmed_reads.fa
# assemble_reads trimmed_reads.fa assembled_genome.fa
# find_genes.py window_size assembled_genome.fa gene_regions.csv 

# - Bioinformatic pipelines can exist of many more steps
# - No prompting user for input (runs on cluster over night)
# - Standardized input/output formats can be used as input/output between programs

##########################################
## Running a python program from terminal

# 1. always include:
def main():
    print("This is the start of my find_genes program")

if __name__ == '__main__':
   main()   # Call the main function if run from terminal

# From terminal: python find_genes.py

##########################################

##########################################
# 2. Parsing arguments from commandline
import sys

def main(w, assm_file, outfile):
    print("The arguments I read were:")
    print(w)
    print(assm_file)
    print(outfile)

if __name__ == '__main__':
    w = int(sys.argv[1])
    assm_file = open(sys.argv[2], 'r')
    outfile = open(sys.argv[3], 'w')
    main(w, assm_file, outfile)   # Call the main function if run from terminal

# From terminal: python find_genes.py 50 test_file.fa outfile.csv

# What happens if you give too many arguments? Too few arguments?  There will be a cryptic error message!
##########################################


##########################################
# 3. The argparse module

import argparse

def main(args):
    print("The arguments I read were:")
    print(args.w)
    print(args.assm_file)
    print(args.outfile)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Find gene region \
                                in a genome assembly through GC content.",
                                formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('w', type = int, 
                        help='Window size to calculate GC content from')
    parser.add_argument('assm_file', type = argparse.FileType('r'), 
                        help = 'input assembly file') 
    parser.add_argument('outfile', type=argparse.FileType('w'), 
                        help = 'Output CSV-file') 
    args = parser.parse_args()
    main(args)   # Call the main function if run from terminal

# From terminal: python find_genes.py 50 test_file.fa outfile.csv
# Too few: python find_genes.py 50 test_file.fa 
# Too many: python find_genes.py 50 test_file.fa outfile.csv another_arg


# Adding arguments:

# Optional integers/floats
parser.add_argument('--a', type=int, default = 2,
                    help='Minimum abundance of ...  ')

# Optional flags (true/false)    
parser.add_argument('--use_rc', action="store_true", 
                    help='Use also reverse complements to find genes')

# several values for an argument:

parser.add_argument('--k', type = int, nargs = 3,
                      help='k-mer sizes to try')

parser.add_argument('--k', type = int, nargs = '*',
                      help='k-mer sizes to try')

##########################################


##########################################
# 3. The full find_genes.py 
#
# Revisit program structure:
# - separated into modular pieces (functions)
# - functions take parameters as input and returns stuff
# - docstrings missing..

import argparse

def read_fasta(f):
    seqs = {}
    for line in f:
        if line[0] == ">":
            acc = line.strip()
            seqs[acc] = ''
        else:
            seqs[acc] += line.strip()
    return seqs

def get_kmer_windows(seq, w):
    return [seq[i:i+w] for i in range(len(seq) - w +1)]

def estimate_gc(kmers):
    return [(kmer.count('C') + kmer.count('G')) / len(kmer) for kmer in kmers]

def get_gene_regions(gc_fractions):
    regions = []
    curr_region_start = 0
    for i in range(len(gc_fractions) - 1):
        # gene region starts
        if gc_fractions[i] < 0.7 and gc_fractions[i+1] >= 0.7:
            curr_region_start = i+1
   
        # gene region is over
        elif gc_fractions[i] >= 0.7 and gc_fractions[i+1] < 0.7:
            regions.append( (curr_region_start, i+1) )
    
    return regions
            

def print_results(chr_id, regions):
    for start, stop in regions:
        print(chr_id, start, stop)

def main(args):
    
    assembly = read_fasta(args.assm_file)
    
    for chr_id, seq in assembly.items():    
        kmers = get_kmer_windows(seq, args.w) # returns list of k-mers in order
        gc_fractions = estimate_gc(kmers) # estimates GC content per kmer, returns list of floats
        regions = get_gene_regions(gc_fractions)
        print_results(chr_id, regions)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Find gene region \
                                in a genome assembly through GC content.", \
                                formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--w', type=int, default = 50, 
                        help='Window size to calculate GC content from')
    parser.add_argument('assm_file', type=argparse.FileType('r'), 
                        help='input assembly file') 
    parser.add_argument('outfile', type=argparse.FileType('w'), 
                        help='Output CSV-file') 
    
    # Below args not implemented in this example (see exercise 2)

    # parser.add_argument('--use_rc', action="store_true", 
    #                     help='Use also reverse complements to find genes')
    # parser.add_argument('--verbose', action="store_true", 
    #                     help='Pring diagnostic output to terminal (stdout)')
    args = parser.parse_args()
    main(args)   # Call the main function if run from terminal



##########################################
# 4. Testing

# It is challenging to guarantee the correctness of one's code.
# Programs typically grow and are modified:
#  - features are added
#  - algorithms (methods) get updated
#  - added support for OS or different settings
#
# Ideal:
# 1. Modify existing code to add new functionality.
# 2. Verify the new functionality.
# 3. Verify the old functionality.
#
# Point 3 is easily overlooked but can be challenging to manage.
# --> What is needed is systematic and automated testing

## Testning with `assert`

# syntax: "assert condition"
data_list = [1,2]
assert len(data_list) > 0
assert x != 0
assert x > 0 and y > 0

# Ex: show test_find_genes.py
##########################################



