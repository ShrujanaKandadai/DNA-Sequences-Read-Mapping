# GENERAL INFO
# 1. Compendium - exerscise solutions: chapters off by one!
# 2. Register to exam -  registration closes 10 days before!
# 3. Projects: 
#      - read the general instructions
#      - Brief inro on Mon/Tue


# CHAPTER 6
# - Error handling (exceptions and raise)





# EX: divide all numbers in list with a number. 

def divide_list(l, x):
    for i in range(len(l)):
        l[i] = l[i]/x # we are modifying the list items here

numbers = [3,6,121,27]
divide_list(numbers, 3)
print(numbers)

# What can go wrong?






# Traditionally (C, older Python / Java / C++ more): 

def divide_list(l, x):
    if type(x) != int and type(x) != float:
        return 11
    elif x == 0:
        return -1
    else:
        # check that elements in list are integers of floats
        for item in l:
            if type(item) not in [int, float]:
                return 12
        for i in range(len(l)):
            l[i] = l[i]/x # we are modifying the list items here
        return 0

# print(divide_list([2,False,3], 2))

return_code = divide_list(l,x)
if return_code == -1:
    # do something
elif return_code == 11:
    # do something else...
elif return_code == 12:
    # do something else...
elif return_code == 0:
    # good!




## In python:

try:
   # unsafe code
   ...
except [ErrorType]:
   # action
   ...

# Rest of the code 



# The previous example rewritten:

def divide_list(l, x):
    try:
        for i in range(len(l)):
            l[i] = l[i]/x # we are modifying the list items here
    except ZeroDivisionError:
        print('The input division number is 0')
    except TypeError:
        print('All entries in the list must be either ints or floats.')

        
numbers = [3,'6',121,27]
divide_list(numbers, 2)
print(numbers)


# When should exception handling be used?
# – For “uncertain/error-prone" sections
# Typical places:

# 1. All file handling.
# 2. Communication with users.
# 3. Your own or others’ code that is “unsafe”
#    (e.g., when implementing an algorithm that is unstable).


# Actions:

# * Critical error: Print an error message and exit, e.g., file not found.
#
# * Non-critical: 
#   1. Ignore the error, print a warning, and continue — for example
#   if you have strange input that can be disregarded and the computations
#   can still proceed.
#   2. Handle the error and continue: works well for some predictable errors;
#   for example, if you get bad input from a user, you can ask them to try again.

## Example 1: communication with user

while True:
    answer = input("Write a number (write 0 to quit): ")
    x = int(answer)
    if x == 0:
        print("Bye bye!")
        break
    else:
        print("The square of the number is: " + str(x ** 2))

# Rewrite with error handling





# Solution below




while True:
    answer = input("Write a number (write 0 to quit): ")
    try:
        x = int(answer)
    except ValueError: # Captures only 'ValueError'
        print("You must write a number!")
        continue

    if x == 0:
        print("Bye bye!")
        break
    else:
        print("The square of the number is: " + str(x ** 2))





# Example 2: File handling: Compute the lengths of rows in a file

def len_file(filename):
    with open(filename, 'r') as h:
        for s in h:
            print(len(s))

len_file("data/kmers.txt")

# Rewrite with error handling










# Solution below


def len_file(filename):
    try:
        with open(filename, 'r') as h:
            for s in h:
                print(len(s))
    except FileNotFoundError:
        print("Could not open file " + filename + " for reading.")

len_file("data/kmers.text")

# another solution

def len_file(filename):
    while True:
        try:
            with open(filename, 'r') as h:
                for s in h:
                    print(len(s))
            break
        except FileNotFoundError:
            print("File " + filename + " not found")
            filename = input("Enter a new path")
            continue

len_file("data/kmmers.txt")





# Example 3: Several error types

def divide_by_elems(filename, x):
    quotients = []
    with open(filename, 'r') as h:
        for n in h:
            frac = x / int(n)
            quotients.append(frac)
    return quotients

# Solution ?
try:
    data = divide_by_elems('numbers.txt', 2)
except IOError:
    print("divide_by_elems: A file-related problem occured.")
except ZeroDivisionError:
    print("divide_by_elems: Division by zero.")
except ValueError:
    print("divide_by_elems: Character could not be converted to int.")

print(data)

# Reflection: When to put error handling within
# the fuction and when to put it outside the function?
# - readability
# - number of calls to the function



# Common errors:

# • TypeError (e.g. 'hej' + 32 )
# • ZeroDivisionError (e.g. 3/0)
# • KeyError (e.g. d['hej'], and 'hej' is not a key in d )
# • FileNotFoundError / IOError (when file reading/writing)
# • IndexError (e.g. l[4] when l= ['a', 99, 2, 'b'])
# • SyntaxError (e.g. "l[4" or "def f()" no colon)
# • ValueError (e.g. int('hello12') or import math;  math.sqrt(-10))
# • ArithmeticError
# • MemoryError
# ....



# RAISE (Managing your own uncertainty)

# The keyword raise is useful for 
#   1. writing more detailed error messages, 
#   2. when an error occurs that isn’t covered 
#      by Python’s existing error handling.

# Ex 1
def head(xs):
    if not xs:
        raise Exception("head: input list is empty")
    else:
        return xs[0]
    
head([])

# Ex 2 find an optima to a funktion with Newton-Raphson

def my_algorithm(x, h):
    while True:
        if h < 0.01:
            raise ArithmeticError('Stepsize h should not be smaller than 0.01.\
                                   The value of h was:', h)

        # check polynomial root
        ...

        # update h
        ...


