
# GENERAL INFO

# * Labs:  Hand in one file with the complete program (final product).
# * Anna-Lena's presentation is avialable on course webpage: 
#      Introduction to the SU spring 2025 semester - 2025-01-20
# * Extension coords


# CHAPTER 2

## Data types and conversion
## More operators (prev. arithmetic, today: comparison, logical, och assignment)
## Functions
## Global and local variables
## Conditionals (if-statements)


#  Data types and conversion

my_int = 1 
my_float = 1.0 
my_string = "1" 
type(my_int) 
type(my_float) 
type(my_string) 
type('hello')

c = my_int + my_float
c = my_int + int(my_string)
# but what about print(int("1.3")) ??
int("hello!")



## More conversions 
x = 2 # test int, float, str

str(x) 
int(x) 
float(x) 
# complex(x) 
bool(x)


## Booleans in Python
# (useful for if-statements)
print(bool(3), bool(-427.2), bool('hello'))

print(bool(0), bool(0.0), bool(''), bool(None)) 


## Operators

# Arithmetic operations in lecture 1

### Comparison operators  ==, !=, >, <, <=, >= ...
# (useful for if-statements)
### (Note: '=='' instead of '=' for checking equality)

print(4 < 7) # works with ints floats complex and more
print('hello shark' < 'Hello shark') # even strings


### Logical operators
# and or not

x = True
y = False
print(x and y)
print(x or y)
print(not y)

z = x and y # True iff both x and y are True
q = x or y # True if either x or y is True

not_z = x and not y # True iff x is True and y is False



### Assignment operations
## (useful for loops, chapter 3)
x = 2

x += 3 # x = x + 3 
x -= 3 # x = x - 3 
x *= 3 # x = x * 3
x /= 3 # x = x / 3 
x %= 3 # x = x % 3 
x //= 3 # x = x // 3 
x **= 3 # x = x ** 3

# Ex 
x = 2
x += 3
x += 3
print(x)


## Functions (and indentation)

def f(x): 
    return 2*x

f(445)


# The point of functions is to organize code 
# in easily handled and reusable pieces
#
# - Avoid repetition of code
# - Simplify advanced programs
# - Increase modularity: a program divided up in small pieces is easier to understand and change than a big, monolithic program
# - Make the program more readable:
#      – Clarify dependencies in the code: indata as arguments, result with return
#      – Dividing code up makes it easier to document.
#      – Dividing code up makes it easier to see that it does what it should (for example by testing, or
#        even just by looking at it).



# Several parameters
def long_name(course_code, course_name): 
    lname = course_code + course_name 
    return lname

long_name("DA7066", "Programming techniques for Life Sciences") 

# No parameters
def show_user_menu(): 
    print('Menu:') 
    print('1. Add user') 
    print('2. List users') 
    print('3. Quit')


# Functions can call functions
def user_choice(): 
    show_user_menu() 
    return input('Which assignment do you want to do? ')


# In most cases however: 
#  1. Make sure your function returns something! 
#  (think about what is suitable to return)
#
#  2. Make sure your function takes parameters! 

def f1(x): 
    return x + x 

def f2(x): 
    print(x + x)


# Multiple return values
def integer_div(nominator, denominator): 
    q = nominator // denominator 
    r = nominator % denominator 
    return q, r


# Default values (keyword parameters)

def f(x=1): 
    return x + x 

print(f()) 
print(f(3))



# Mixed

def f(x, y=1): 
    return x + y 

def f(x=1, y):  # error
    return x + y 

# Also in print:
print('hello', 'you', sep='\n')

help(print)



# Documentation strings

def square(x): 
    """
    This function takes an integer and returns its square.
    
    Parameters:
    x (int): input number 

    Returns: 
    int: Square of x
    """ 
    return x*x 

print(square.__doc__)

help(square)



# Global och local variables


# global variables can be accessed in functions
x="hello"

def foo(): 
    print("x printed from inside foo:", x) 

foo() 
print("x printed from outside foo:", x)




# 'Scope' (visibility)
# We cannot change the value inside the function, only access for "reading". 

# Ex 1
x=42 
def foo():
    x=x*2 # Error on this line
    print("x printed from inside foo:", x)  
foo()
print("x printed from outside foo:", x)


# Ex 2
# the local x variable is temporary and destroyed after the function call 
x=5
def foo(): 
    x=10 
    print("local x:", x) 
foo() 
print("global x:", x)





# Conditionals (if-statements)


# Simple if
answer=input('Write "done" if you are done:') 

if answer=='done': 
    quit() 

print("Okay, I guess you're not finished yet.")


# if-else
namn=input('What is your name?') 


if namn == 'Kristoffer': 
    print('Hello Kristoffer!') 
else: 
    print('Hello, whoever you are!')


# if-elif-else

temp = int(input('What is the temperature?')) 
if temp < -30: 
    print('That is very cold!') 
elif temp < 0:
    print('That is pretty cold...') 
elif temp == 0:
    print('Zero') 
elif temp < 30:
    print('That is a comfortable temperature') 
else: 
    print('Wow! Superwarm')


#################### IF TIME #######
# Example 2

v = input("What do yo want to enter? Type 'n' for name or 'i' for integer.") 
if v == "n": 
    name = input("Enter name:")
    print("Hej", name)
elif v == "i":
    i = input("Enter integer:")
    print(i*42)
else:
    print("alternative invalid")


# In a function: 

def user_menu():
    v = input("What do yo want to enter? Type 'n' for name or 'i' for integer.") 
    if v == "n": 
        name = input("Enter name:")
        print("Hej", name)
        user_menu()
    elif v == "i":
        i = input("Enter integer:")
        print(i*42)
        user_menu()
    else:
        print("alternative invalid")
        
        
# Example 3 (related to recursion) 
# can you spot the error in the below function? (why doesn't it finish?)

def play_guess():
    correct = 42
    g = input("Guess a number.") 
    if g == correct:
        print("Congrats, you guessed correctly")
    else:
        print("Not correct")
        play_guess()



# Example 4 

    
def is_prime(x):
    if x >= 2:
        for y in range(2,x):
            if not ( x % y ):
                return False
    else:
        return False
    return True
    
    
v = input("Which game do yo want to play? 1. Number guessing game, 2. Prime number game: ") 


if v == '1':
    play_guess()
elif v == '2':
    is_prime()
else:
    print("Wrong choice")
    
