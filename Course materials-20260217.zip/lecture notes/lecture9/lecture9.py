# GENERAL INFO
# Read mapping project: updated text
# Updated off-by-one error in compendium


# Unix environment
#
# Popular in bioinformatics (will encounter it if project 
# in a bioinformatics group)
# Nearly all bioinformatics software is written for Unix systems.
# (many cannot be compiled on windows machines)
#
# Not on a unix machine? Virtual unix environment, e.g.: 
# https://www.tutorialspoint.com/linux_terminal_online.php
#
# Purpose: You have seen the terminal and how you can interact with files
# learned some basic (and useful!) commands, e.g., peak at large files
#
# - Not really needed for the project (except cd to folder and starting your program)
# - Will likely be one question on the exam.
 


# Some commands

### navigation
# - cd (change directory) (previous: cd -, home: cd , relative to home: cd ~/ )
# - pwd (print working directory)
# - ls (list contents) ls -lh

### Creating files and folders
# - touch file.txt (create an empty file.txt)
# - mkdir (make directory) useful: mkdir -p
# - cp (copy paste)
# - mv (move)
# - rm (remove)
# * is a match all "wildcard" symbol. e.g, mv file* testdir/testdir2/testdir3/

### Information about files
# - wc
# - head
# - tail
# - grep: Searches for patterns/strings in files. Example: `grep "error" file.txt` finds lines containing the word "error" in `file.txt`.

# Ex: wc -l data.txt 


# * Running programs in background (&)
#     - Example: 'python sum.py &'
#     - Checking current programs: 'jobs'/'ps'/'top'
#     - To kill: 'kill PID'

# # Signals: 

# - 'Ctrl-C': signal which cancels or terminates the currently-running program
# - 'Ctrl-Z: Temporarily stop program (send to background)
# - 'fg [JOBID]' restart the job
# - `Cmd-L` (Mac)/`Ctrl-L` : Clear the output of last command
# - `Cmd-K` (Mac)/ `Ctrl-K` Clear the terminal screen.


# * Composing command lines
#     - mkdir x; cd x; mv ../hej.txt .; echo 'Done' (Continues even if one command fails)
#     - mkdir x && cd x && mv ../hej.txt . && echo 'Done' (Stops at the command failing)


# * Streams
#     - stdin: where your tool/program can read from
#     - stdout: where your tool/program can write output to
#     - stderr: where your tool/program can complain
#     - Example 
#         a. python program.py
#         b. python program.py > stdout.txt
#         c. python program.py > stdout.txt 2> stderr.txt
#     - Example2: 
#         a. python program2.py < data.txt
#         b python program2.py < data.txt > outdata.txt

    
# * Pipes ('pipelines')
#     - Example: Count the number of unique numbers in column 2 in the file data.txt
#         cut -f 2 -d ',' data.txt | sort | uniq | wc -l


# The terminal is great for investigating large files
# Some of my most used commands when analyzing what is going wrong in a 
# bioinformatic analysis:
# 1. head/tail to check formatting errors
# 2. wc to check other unexpected things (number of lines not matching estimate in fasta)
# 3. grep for only certain lines. For example, unexpectedly many reads or contigs:
#    grep '>' reads.fa | wc -l
#    grep "error" logfile.txt
# 