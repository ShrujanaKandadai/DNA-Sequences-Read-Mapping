#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#2.2
def odd_or_even():
    number = int(input("Enter an integer: "))
    if number % 2 == 1:
        print("Odd")
    else:
        print("Even")
    # Alternative
    # answer = "Odd" if number % 2 == 1 else "Even"
    # print(answer)


#2.5
def division(x, y):
    if y == 0:
        if x == 0:
            print("Indeterminate form")
        else:
            print("The result is infinite")
    else:
        return x / y

odd_or_even()
print(division(2, 5))
division(2, 0)
division(0, 0)

x = True
y = False
z = True
t = True

# x and y or z and t # Need to know operator priority to evaluate

#2.7
def nand(x, y):
    return not(x and y)


def nor(x, y):
    return not(x or y)


def xnor(x, y):
    return (not x and not y) or (x and y)
    # return x == y

#2.8

print(3 and 2)
print(0 and 2)
print(3 or 2) # 3
print([] or "444")