# import random
from random import randint, uniform, choices
#7.1
random_list = []
for _ in range(11):
    # random_int = randint(1, 101)
    random_element = uniform(1, 100)
    random_list.append(random_element)

random_int_list = choices(range(1, 101), k=10)
print(random_int_list)

print(random_list)

#7.2

def is_perfect(x):
    sum = 0
    for i in range(1, x):
        if (x % i == 0):
            sum = sum + i
    return x == sum


def is_prime(x):
    if x >= 2:
        prime = True
        for y in range(2,x):
            if not (x % y):
                prime = False
    else:
        prime = False
    return prime


def analyze_number(x, perfect_or_prime, function):
    if function(x):
        print(f"The number is {perfect_or_prime}")
    else:
        print(f"The number is {perfect_or_prime}")


def choose_input():
    while True:
        choice = input("C for choosing the number, R for a random number")
        if choice == "C":
            return int(input("Provide a number to analyze: \n"))
        elif choice == "R":
            return randint(1, 101)
        else:
            print("Please provide either C or R")


def main():
    x = choose_input()

    if is_perfect(x):
        print("The number is perfect")
    else:
        print("The number is not perfect")
    if is_prime(x):
        print("The number is prime")
    else:   
        print("The number is not prime")
    # analyze_number(x, "perfect", is_perfect)
    # analyze_number(x, "prime", is_prime)

main()


def substring_occurences(seq, k):
    substrings = {}
    for i in range(len(seq) - k + 1):
        substring = seq[i: i+k]
        if substring in substrings:
            substrings[substring] += 1
        else:
            substrings[substring] = 1
    return substrings


def find_most_frequent(substrings):
    max_count = 0
    most_freq_substring = ""
    for substring, count in substrings.items():
        if count > max_count:
            most_freq_substring = substring
            max_count = count
    return most_freq_substring


def find_substring_positions(seq, k, substring):
    positions = []
    for i in range(len(seq) - k + 1):
        substring = seq[i: i+k]
        if substring == substring:
            positions.append(i)


def find_distances(positions):
    distances = []
    # list_1 = (x1, x2, x3)
    # list_2 = (y1, y2, y3)
    # zip(list_1, list_2) = [(x1, y1), (x2, y2), (x3, y3)]
    for p1,p2 in zip(positions[:-1], positions[1:]):
        distances.append(p2 - p1)
    return distances


#7.4
seq = input("Enter a dna string: ")
k = 3
substrings = substring_occurences(seq, k)
most_freq_substring = find_most_frequent(substrings)
positions = find_substring_positions(seq, k, most_freq_substring)
print(find_distances(positions))