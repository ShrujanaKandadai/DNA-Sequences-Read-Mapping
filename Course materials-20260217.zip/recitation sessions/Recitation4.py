#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#5.1
def all_zero(p_list):
    """ Check if all elements are zero.
    :param p_list: list of integers
    :return: boolean
    """
    for x in p_list:
        if x != 0:
            return "False"
        else:
            return "True"
        

#5.2    
def add_hyphens(text):
    """ Adds a hyphen between letters
    :param text: string
    :return: string
    """
    new_text = ""

    for idx in range(len(text)):
        if idx == len(text) - 1:
            # add last letter
            new_text += text[idx]
        else:
            new_text += text[idx] + "-"
        # print(f"After iteration {idx} result is {new_text}")
    return new_text

print(add_hyphens("word")) # w-o-r-d
assert(add_hyphens("word") == "w-o-r-d")
