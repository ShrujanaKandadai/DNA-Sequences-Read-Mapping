#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#3.1

print([1, 2] + ['a', 'b'])

#3.2
# print(min(["sting", 1])) Error: can not compare int and str types
print(max([1, 1.5, 100.5])) # 100.5
print(max([0, 0.5, 0.9, True])) # True
print(max([1, 0.5, 0.9, True])) # 1
print(max([True, 0.5, 0.9, 1])) # True

#3.3
def vowels(s):
    vs = "AEIOUYaeiouy"
    result = ""
    for ch in s:
        if ch in vs:
            result += ch
    return result
    # return " ".join(result)

print(vowels("yesterday"))


#3.4
def vowels_and_consonants(s, choice):
    vs = "AEIOUYaeiouy"
    result = ""
    for ch in s:
        if choice == "vowels":
            if ch in vs:
                result += ch
        else:
            if ch not in vs:
                result += ch
    return result


# print(vowels_and_consonants("tomorrow", "vowels"))
# print(vowels_and_consonants("tomorrow", "consonants"))

#3.5
def split(s):
    out = []
    term = ""
    
    for c in s:
        if c == " ":
            if term != "":
                out.append(term)
            term = ""
        else:
            term += c
            
    if term != "":
        out.append(term)
    return out


print(split("hej how    are you?"))


#3.6
list = [1,2,3]
list2 = list
list2.reverse()
print(list)

#3.8
n = 10
while n > 0: 
    n -= 1 # 9 8 ... 0
    if n == 7:
        pass
    print(n)