import argparse
def read_fasta(f):
    seqs = {}
    try:
        for line in f: 
            if line[0] == ">":
                acc = line.strip()
                seqs[acc] = ''
            else:
                seqs[acc] += line.strip()
        return seqs
    except:
        raise ValueError("The fasta file is malformatted")


def get_reverse_complement(seq):
    rc_nucleotide = {"A": "T", "C": "G", "G": "C", "T": "A"}
    result = ""
    for ch in seq:
        result += rc_nucleotide[ch]
    return result[::-1]


def get_kmer_windows(seq, w):
    # lst = []
    # for x in range(1, 10):
    #     lst.append(x)

    # lst = [2 * x for x in range(1, 10)]
    # print(lst)
    # for i in range(len(seq) - w + 1):
    #     lst.append(seq[i:i+w])
    return [seq[i:i+w] for i in range(len(seq) - w + 1)]


def estimate_gc(kmers):
    return [(kmer.count('C') + kmer.count('G')) / len(kmer) for kmer in kmers]


def get_gene_regions(gc_fractions, gc_threshold):
    regions = []
    curr_region_start = 0
    for i in range(len(gc_fractions) - 1):

        # gene region starts
        if gc_fractions[i] < gc_threshold and gc_fractions[i+1] >= gc_threshold:
            curr_region_start = i+1
            
        # gene region is over
        elif gc_fractions[i] >= gc_threshold and gc_fractions[i+1] < gc_threshold:
            regions.append( (curr_region_start, i+1) )
    return regions


def print_results(chr_id, regions, outfile):
    for start, stop in regions:
        outfile.write(f"{chr_id} {start} {stop}\n")

    
def main(args):
    assembly = read_fasta(args.assm_file)

    for chr_id, seq in assembly.items():
        kmers = get_kmer_windows(seq, args.w) # returns list of k-mers in order
        # if args.verbose:
        #     print(kmers)
        gc_fractions = estimate_gc(kmers) # estimates GC content per kmer, returns list of floats
        regions = get_gene_regions(gc_fractions, args.gc_threshold)
        print_results(chr_id, regions, args.outfile)

        # Can be moved into a separate function
        if args.use_rc:
            rc_seq = get_reverse_complement(seq)
            rc_kmers = get_kmer_windows(rc_seq, args.w)
            reverse_gc_fractions = estimate_gc(rc_kmers)
            reverse_regions = get_gene_regions(reverse_gc_fractions, args.gc_threshold)
            print_results(chr_id + "_2", reverse_regions, args.outfile)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Find gene region \
    in a genome assembly through GC content.", \
    formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--w', type=int, default = 50,
    help='Window size to calculate GC content from')
    parser.add_argument('assm_file', type=argparse.FileType('r'),
    help='input assembly file')
    parser.add_argument('outfile', type=argparse.FileType('w'),
    help='Output CSV-file')
    parser.add_argument("--gc_threshold", type=float, default=0.7, 
                        help="Threshold for GC-rich regions")
    # Below args not implemented in this example (see exercise 2)
    parser.add_argument('--use_rc', action="store_true",
    help='Use also reverse complements to find genes')
    parser.add_argument('--verbose', action="store_true",
    help='Pring diagnostic output to terminal (stdout)')
    args = parser.parse_args()
    main(args)
# Call the main function if run from terminal