#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#4.1
a = ['a', 'b', 'c']
b = [1, 2, 3]
d = {}
for i in range(len(a)):
    # d[a[i]] = b[i]
    key = a[i]
    value = b[i]
    d[key] = value
print(d)

#4.2, 4.3
def GCD(a,b):
    if b > a:
        print("a must be bigger than b in GCD(a,b)")
        return None
    r = a % b
    while r != 0:
        a = b
        b = r
        r = a % b
    return b


print("x y GCD")
for y in range(2, 6):
    for x in range(y + 1, 6):
        # if x == y:
        #     continue
        # if x < y:
        #     x1, y1 = y, x
        print(x, y, GCD(x, y))

print("=================================")

#4.4
def vowels(s):
    vowels = {'a': 1, 'e': 2, 'i': 3, 'o': 4, 'u': 5, 'y': 6}
    out = ""
    for c in s:
        if c in vowels:
            out += str(vowels[c])
        else:
            out += c
    return out
print(vowels("Hey Anders!"))


#4.5
def annotate_word(s):
    out = []
    term = ""
    for c in s:
        if c == " ":
            out.append(term)
            term = ""   
        else:
            term += c
    # add the final word unless it is empty
    if term != "":
        out.append(term)

    out # list of words
    words_dict = {}
    for i in range(len(out)):
        words_dict[out[i]] = i + 1
    reverse = {}
    for key, value in words_dict.items():
        reverse[value] = key

    return reverse


print(annotate_word("Hey Anders! Hey are you?"))