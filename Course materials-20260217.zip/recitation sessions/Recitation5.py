def divide_by_elems(filename, x):
    try:
        y = int(x)
    except ValueError:
        return None
    quotients = []
    h = open(filename, 'r')
    for n in h:
        print(quotients)
        try:
            frac = y / int(n)
        except:
            continue
        quotients.append(frac)
    h.close()
    return quotients

# 1
# 2
# O
# 4
# 3
# 0

try:
    data = divide_by_elems('numbers.txt', "2")
    print(data)
except IOError:
    print("divide_by_elems: A file-related problem occurred.")
except ZeroDivisionError:
    print("divide_by_elems: Division by zero.")
except ValueError:
    print("divide_by_elems: Character could not be converted to int.")
# except TypeError:
#     print("The argument should not be a string")